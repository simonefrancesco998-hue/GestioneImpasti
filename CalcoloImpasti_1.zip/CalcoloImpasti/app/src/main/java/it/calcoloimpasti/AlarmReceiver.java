package it.calcoloimpasti;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;

public class AlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "fasi_impasto";
    private static final long SNOOZE_MS = 5 * 60 * 1000L;

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        int id = intent.getIntExtra("id", 0);
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        if (title == null) title = "";
        if (text == null) text = "";
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);

        try {
            if (AlarmScheduler.ACTION_SNOOZE.equals(action)) {
                nm.cancel(id);
                long at = System.currentTimeMillis() + SNOOZE_MS;
                AlarmScheduler.schedule(c, id, at, title, text);
                if (id != AlarmScheduler.TEST_ID) AlarmScheduler.store(c, id, at, title, text);
                return;
            }
            if (AlarmScheduler.ACTION_FIRE.equals(action)) {
                if (id != AlarmScheduler.TEST_ID) AlarmScheduler.removeStored(c, id);
                show(c, nm, id, title, text);
            }
        } catch (Exception ignored) {
        }
    }

    private void show(Context c, NotificationManager nm, int id, String title, String text) {
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Fasi impasto", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Sveglie di fine fase");
        ch.setSound(sound, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 600, 300, 600, 300, 600});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);

        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snooze = new Intent(c, AlarmReceiver.class).setAction(AlarmScheduler.ACTION_SNOOZE);
        snooze.putExtra("id", id);
        snooze.putExtra("title", title);
        snooze.putExtra("text", text);
        PendingIntent snoozePi = PendingIntent.getBroadcast(c, id, snooze,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_sveglia)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(open)
                .addAction(0, "Rimanda 5 min", snoozePi)
                .build();
        n.flags |= Notification.FLAG_INSISTENT; // il suono si ripete finché non la chiudi
        nm.notify(id, n);
    }
}
