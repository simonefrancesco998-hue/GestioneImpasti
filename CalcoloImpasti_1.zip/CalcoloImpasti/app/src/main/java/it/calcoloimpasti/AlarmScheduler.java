package it.calcoloimpasti;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** Programma e conserva le sveglie delle fasi. Usa setAlarmClock: suona anche in Doze, senza permessi speciali. */
final class AlarmScheduler {

    static final String ACTION_FIRE = "it.calcoloimpasti.ALARM_FIRE";
    static final String ACTION_SNOOZE = "it.calcoloimpasti.ALARM_SNOOZE";
    static final int TEST_ID = 999999;

    private static final String PREFS = "sveglie";
    private static final String KEY = "lista";

    private AlarmScheduler() {}

    private static PendingIntent firePending(Context c, int id, String title, String text) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION_FIRE);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("text", text);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c, int id, long at, String title, String text) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), firePending(c, id, title, text));
    }

    private static void cancel(Context c, int id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(firePending(c, id, "", ""));
    }

    private static JSONArray load(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            return new JSONArray(p.getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }

    /** Sostituisce tutte le sveglie con la lista ricevuta dalla pagina: [{id, at, title, text}]. */
    static synchronized void sync(Context c, String json) throws Exception {
        JSONArray old = load(c);
        for (int i = 0; i < old.length(); i++) {
            cancel(c, old.getJSONObject(i).getInt("id"));
        }
        JSONArray incoming = new JSONArray(json);
        JSONArray kept = new JSONArray();
        long now = System.currentTimeMillis();
        for (int i = 0; i < incoming.length(); i++) {
            JSONObject o = incoming.getJSONObject(i);
            long at = o.getLong("at");
            if (at <= now) continue;
            schedule(c, o.getInt("id"), at, o.optString("title"), o.optString("text"));
            kept.put(o);
        }
        save(c, kept);
    }

    /** Aggiunge o aggiorna una voce (usato dal "Rimanda"). */
    static synchronized void store(Context c, int id, long at, String title, String text) throws Exception {
        JSONArray old = load(c);
        JSONArray out = new JSONArray();
        for (int i = 0; i < old.length(); i++) {
            if (old.getJSONObject(i).getInt("id") != id) out.put(old.getJSONObject(i));
        }
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("at", at);
        o.put("title", title);
        o.put("text", text);
        out.put(o);
        save(c, out);
    }

    static synchronized void removeStored(Context c, int id) throws Exception {
        JSONArray old = load(c);
        JSONArray out = new JSONArray();
        for (int i = 0; i < old.length(); i++) {
            if (old.getJSONObject(i).getInt("id") != id) out.put(old.getJSONObject(i));
        }
        save(c, out);
    }

    /** Dopo il riavvio Android cancella gli allarmi: li ripianifico. */
    static synchronized void rescheduleAll(Context c) throws Exception {
        JSONArray a = load(c);
        JSONArray kept = new JSONArray();
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            if (o.getLong("at") <= now) continue;
            schedule(c, o.getInt("id"), o.getLong("at"), o.optString("title"), o.optString("text"));
            kept.put(o);
        }
        save(c, kept);
    }
}
