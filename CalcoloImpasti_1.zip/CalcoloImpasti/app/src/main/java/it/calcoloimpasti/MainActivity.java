package it.calcoloimpasti;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final int REQ_NOTIF = 1;
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);
        // lo schermo resta acceso mentre l'app è aperta (utile con le mani sporche di farina)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // serve per salvare ricette e piano (localStorage)

        web.addJavascriptInterface(new Bridge(), "AndroidAlarm");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                }
                return false;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        notifyPage(); // aggiorna lo stato dei permessi dopo il ritorno dalle impostazioni
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (!ok) openNotificationSettings();
            notifyPage();
        }
    }

    private void notifyPage() {
        if (web != null) {
            web.evaluateJavascript("window.onAlarmPermission && window.onAlarmPermission()", null);
        }
    }

    private boolean notificationsAllowed() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.areNotificationsEnabled();
    }

    private void openNotificationSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        startActivity(i);
    }

    /** Ponte chiamato dalla pagina come window.AndroidAlarm. I metodi girano su un thread secondario. */
    private class Bridge {

        @JavascriptInterface
        public void sync(String json) {
            try {
                AlarmScheduler.sync(getApplicationContext(), json);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public boolean hasPermission() {
            return notificationsAllowed();
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                    } else if (!notificationsAllowed()) {
                        openNotificationSettings();
                    }
                }
            });
        }

        @JavascriptInterface
        public void test() {
            AlarmScheduler.schedule(getApplicationContext(), AlarmScheduler.TEST_ID,
                    System.currentTimeMillis() + 10000L, "Prova sveglia", "Le sveglie funzionano.");
        }
    }
}
